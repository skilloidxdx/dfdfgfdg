import Image from "next/image";

const women = [
  {
    id: 1,
    name: "Sabine, 54",
    region: "Berlin",
    img: "https://randomuser.me/api/portraits/women/62.jpg",
    about: "Mag Spaziergänge, Kochen und gute Gespräche.",
    interests: "Bücher, Musik, Reisen"
  },
  {
    id: 2,
    name: "Angelika, 63",
    region: "Hamburg",
    img: "https://randomuser.me/api/portraits/women/68.jpg",
    about: "Lebensfroh, ehrlich, liebt Theater und Kultur.",
    interests: "Kunst, Theater, Natur"
  },
  {
    id: 3,
    name: "Claudia, 58",
    region: "München",
    img: "https://randomuser.me/api/portraits/women/65.jpg",
    about: "Reiselustig, sucht nette Bekanntschaft.",
    interests: "Reisen, Familie, Tiere"
  }
];

export default function HomeFeed() {
  return (
    <main className="max-w-2xl mx-auto py-8 px-2">
      <h1 className="text-2xl font-bold text-blue-900 mb-6 text-center">Frauen entdecken</h1>
      <form className="flex flex-wrap gap-4 mb-8 justify-center">
        <label className="text-blue-800">
          Alter:
          <select className="ml-2 px-2 py-1 rounded border border-blue-200" defaultValue="all">
            <option value="all">Alle</option>
            <option value="45-55">45-55</option>
            <option value="56-65">56-65</option>
            <option value="66-80">66-80</option>
          </select>
        </label>
        <label className="text-blue-800">
          Region:
          <select className="ml-2 px-2 py-1 rounded border border-blue-200" defaultValue="all">
            <option value="all">Alle</option>
            <option value="Berlin">Berlin</option>
            <option value="Hamburg">Hamburg</option>
            <option value="München">München</option>
          </select>
        </label>
        <button type="submit" className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded">Filtern</button>
      </form>
      <div className="flex flex-col gap-6">
        {women.map((w) => (
          <div key={w.id} className="flex flex-col md:flex-row items-center md:items-start bg-white rounded-xl shadow p-6 md:gap-8 gap-4">
            <Image src={w.img} alt={w.name} width={96} height={96} className="rounded-full border-2 border-blue-200" />
            <div className="flex-1">
              <h2 className="text-xl font-semibold text-blue-900">{w.name} <span className="text-blue-700 text-sm ml-2">({w.region})</span></h2>
              <p className="text-blue-800 mt-1 mb-1">{w.about}</p>
              <div className="text-blue-600 text-sm">Interessen: {w.interests}</div>
              <div className="mt-4 flex gap-4">
                <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Gefällt mir</button>
                <button className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded">Nachricht senden</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
