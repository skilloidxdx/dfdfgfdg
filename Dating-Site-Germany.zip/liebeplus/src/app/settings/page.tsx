export default function SettingsPage() {
  const user = {
    name: "Thomas Müller",
    email: "thomas.mueller@mail.de",
    phone: "+49 170 1234567",
    age: 61
  };
  return (
    <main className="max-w-lg mx-auto py-10 px-2">
      <h1 className="text-2xl font-bold text-blue-900 mb-4">Einstellungen</h1>
      <div className="bg-white rounded-2xl shadow-xl p-8 space-y-6">
        <div>
          <div className="mb-2 text-blue-800">Name: <span className="font-semibold">{user.name}</span></div>
          <div className="mb-2 text-blue-800">E-Mail: <span className="font-semibold">{user.email}</span></div>
          <div className="mb-2 text-blue-800">Telefon: <span className="font-semibold">{user.phone}</span></div>
          <div className="mb-2 text-blue-800">Alter: <span className="font-semibold">{user.age}</span></div>
        </div>
        <button className="w-full bg-blue-600 hover:bg-blue-800 text-white font-medium py-2 px-5 rounded-lg">Passwort ändern</button>
        <button className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-5 rounded-lg mt-2">Konto löschen</button>
      </div>
    </main>
  );
}
