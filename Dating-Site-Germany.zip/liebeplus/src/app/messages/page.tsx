const chats = [
  {
    id: 1,
    name: "Sabine, 54",
    lastMessage: "Bis bald! 😊",
    unread: true,
    messages: [
      { fromMe: false, text: "Hallo Thomas! Wie geht es dir?", time: "09:30" },
      { fromMe: true, text: "Mir geht's gut, und dir?", time: "09:31" },
      { fromMe: false, text: "Alles bestens! Was machst du heute?", time: "09:32" },
      { fromMe: true, text: "Ich mache einen Spaziergang im Park.", time: "09:34" },
      { fromMe: false, text: "Toll! Bis bald! 😊", time: "09:36" }
    ]
  },
  {
    id: 2,
    name: "Angelika, 63",
    lastMessage: "Danke für Ihre nette Nachricht!",
    unread: false,
    messages: [
      { fromMe: false, text: "Danke für Ihre nette Nachricht!", time: "Gestern" }
    ]
  }
];

export default function MessagesPage() {
  const selected = chats[0];
  return (
    <main className="flex max-w-4xl mx-auto min-h-[70vh] py-8 gap-8 px-2">
      <aside className="w-1/3 min-w-[200px] flex flex-col gap-2">
        <h2 className="text-lg font-bold text-blue-900 mb-2">Chats</h2>
        <div className="flex flex-col gap-2">
          {chats.map((chat) => (
            <button key={chat.id} className={`flex items-center gap-2 p-3 rounded-lg transition text-left ${selected.id===chat.id ? 'bg-blue-100' : 'bg-white hover:bg-blue-50'} border border-blue-200 font-medium` }>
              <span className="flex-1">{chat.name}</span>
              {chat.unread && <span className="bg-red-500 text-white rounded-full px-2 py-0.5 text-xs ml-1">Neu</span>}
            </button>
          ))}
        </div>
      </aside>
      <section className="flex-1 flex flex-col bg-white rounded-2xl shadow-xl p-6">
        <div className="flex-1 flex flex-col gap-2 overflow-y-auto pb-4">
          {selected.messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.fromMe ? 'justify-end' : 'justify-start' }`}>
              <div className={`max-w-[60%] px-4 py-2 rounded-2xl ${msg.fromMe ? 'bg-blue-200 text-blue-900' : 'bg-blue-50 text-blue-900'} mb-1`}>{msg.text}<span className="ml-2 text-xs text-blue-400">{msg.time}</span></div>
            </div>
          ))}
        </div>
        <form className="flex gap-2 mt-4">
          <input type="text" placeholder="Nachricht schreiben..." className="flex-1 border border-blue-300 px-3 py-2 rounded-l-lg focus:outline-none" />
          <button type="submit" className="bg-blue-700 hover:bg-blue-800 text-white px-6 py-2 rounded-r-lg">Senden</button>
        </form>
      </section>
    </main>
  );
}
