export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col items-center py-8 px-4">
      <header className="w-full max-w-2xl flex flex-col items-center text-center gap-8">
        <h1 className="text-4xl md:text-5xl font-bold leading-tight text-blue-900">
          LiebePlus – Ehrliche Partnersuche ab 45
        </h1>
        <p className="text-lg md:text-xl text-blue-800">
          Finden Sie neue Bekanntschaften und echte Beziehungen.<br />
          Für Männer von 45 bis 80 Jahre in Deutschland.
        </p>
        <a href="/register" className="mt-4 bg-blue-700 hover:bg-blue-800 text-white text-lg font-semibold px-8 py-3 rounded-lg shadow transition">Jetzt kostenlos registrieren</a>
      </header>
      <section className="w-full max-w-2xl mt-12 bg-white/90 p-8 rounded-lg shadow flex flex-col gap-6">
        <h2 className="text-2xl font-bold text-blue-900">Warum LiebePlus?</h2>
        <ul className="space-y-4 text-blue-800 text-base">
          <li>• Einfache, verständliche Bedienung, auch am Handy und Tablet</li>
          <li>• Großzügige Profile mit Bildern und Hobbys</li>
          <li>• 100% deutschsprachig & für erfahrene Menschen entwickelt</li>
          <li>• Sicher, anonym & diskret</li>
          <li>• Persönlicher Kundenservice</li>
        </ul>
      </section>
      <section className="w-full max-w-2xl mt-14">
        <h2 className="text-xl font-bold text-blue-900 mb-4">Was sagen unsere Nutzer?</h2>
        <div className="flex flex-col gap-6 md:flex-row md:gap-8">
          <div className="bg-blue-100 rounded-lg px-6 py-4 shadow text-blue-900 flex-1">
            <p className="italic mb-2">
              „Ich habe hier neue Freunde und meine neue Liebe gefunden. Sehr seriös und einfach.”
            </p>
            <span className="font-semibold">— Michael, 59 aus Hamburg</span>
          </div>
          <div className="bg-blue-100 rounded-lg px-6 py-4 shadow text-blue-900 flex-1">
            <p className="italic mb-2">
              „Die Bedienung macht Spaß. Endlich ein Portal für unsere Generation.”
            </p>
            <span className="font-semibold">— Karl, 67 aus München</span>
          </div>
        </div>
      </section>
      <footer className="mt-14 text-blue-800 text-sm text-center opacity-80">
        © 2024 LiebePlus. Gemeinsam neue Wege gehen.
      </footer>
    </main>
  );
}
