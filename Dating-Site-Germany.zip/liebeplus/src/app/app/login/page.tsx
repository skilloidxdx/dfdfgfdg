import Link from "next/link";

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white px-4">
      <section className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8 flex flex-col gap-6">
        <h1 className="text-2xl font-bold text-blue-900 text-center mb-2">Anmelden</h1>
        <form className="flex flex-col gap-4">
          <label className="text-blue-900 text-sm font-medium">E-Mail oder Telefonnummer
            <input type="text" name="user" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Ihre E-Mail-Adresse oder Handynummer" autoComplete="username" required />
          </label>
          <label className="text-blue-900 text-sm font-medium">Passwort
            <input type="password" name="password" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Ihr Passwort" autoComplete="current-password" required />
          </label>
          <button type="submit" className="mt-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition">
            Einloggen
          </button>
        </form>
        <div className="text-center text-blue-800 mt-2">
          Noch kein Konto?{' '}
          <Link href="/register" className="text-blue-700 hover:underline font-medium">Jetzt registrieren</Link>
        </div>
      </section>
    </main>
  );
}
