import Link from "next/link";

export default function RegisterPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white px-4">
      <section className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8 flex flex-col gap-6">
        <h1 className="text-2xl font-bold text-blue-900 text-center mb-2">Registrieren</h1>
        <form className="flex flex-col gap-4">
          <label className="text-blue-900 text-sm font-medium">E-Mail oder Telefonnummer
            <input type="text" name="user" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Ihre E-Mail-Adresse oder Handynummer" autoComplete="username" required />
          </label>
          <label className="text-blue-900 text-sm font-medium">Vollständiger Name
            <input type="text" name="name" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Ihr Name" autoComplete="name" required />
          </label>
          <label className="text-blue-900 text-sm font-medium">Alter
            <input type="number" name="age" min="45" max="100" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Ihr Alter" required />
          </label>
          <label className="text-blue-900 text-sm font-medium">Geschlecht
            <select name="gender" className="mt-1 w-full border border-blue-300 rounded-lg p-2" required>
              <option value="">Bitte wählen</option>
              <option value="male">Männlich</option>
              <option value="female">Weiblich</option>
            </select>
          </label>
          <label className="text-blue-900 text-sm font-medium">Passwort
            <input type="password" name="password" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Passwort erstellen" autoComplete="new-password" required />
          </label>
          <label className="text-blue-900 text-sm font-medium">Passwort wiederholen
            <input type="password" name="password2" className="mt-1 w-full border border-blue-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Wiederholen Sie das Passwort" autoComplete="new-password" required />
          </label>
          <button type="submit" className="mt-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition">
            Jetzt registrieren
          </button>
        </form>
        <div className="text-center text-blue-800 mt-2">
          Bereits registriert?{' '}
          <Link href="/login" className="text-blue-700 hover:underline font-medium">Hier einloggen</Link>
        </div>
      </section>
    </main>
  );
}
