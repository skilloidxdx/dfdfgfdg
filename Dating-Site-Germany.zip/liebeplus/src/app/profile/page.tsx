import Image from "next/image";

export default function ProfilePage() {
  // демо-данные пользователя
  const user = {
    name: "Thomas Müller",
    age: 61,
    region: "Leipzig",
    img: "https://randomuser.me/api/portraits/men/65.jpg",
    about: "Suche nette Bekanntschaften und inspirierende Gespräche. Genieße Spaziergänge im Park und Reisen.",
    interests: "Reisen, Natur, Musik, Familie"
  };
  return (
    <main className="max-w-xl mx-auto py-10 px-2">
      <h1 className="text-2xl font-bold text-blue-900 mb-6 text-center">Mein Profil</h1>
      <div className="bg-white rounded-2xl shadow-xl p-8 flex flex-col items-center gap-6">
        <Image src={user.img} alt={user.name} width={112} height={112} className="rounded-full border-4 border-blue-300" />
        <h2 className="text-xl font-semibold text-blue-900">{user.name}, {user.age}</h2>
        <span className="text-blue-700">{user.region}</span>
        <p className="mt-4 text-blue-800 text-center">{user.about}</p>
        <div className="text-blue-700 mt-2 mb-4">Interessen: <span className="font-medium">{user.interests}</span></div>
        <button className="bg-blue-700 hover:bg-blue-800 text-white text-base font-medium px-6 py-2 rounded-lg shadow transition">Profil bearbeiten</button>
      </div>
    </main>
  );
}
